package demos.gui.uicomponents;

import io.datafx.controller.ViewController;

@ViewController(value = "/fxml/ui/ToggleButton.fxml", title = "Material Design Example")
public class ToggleButtonController {

}
