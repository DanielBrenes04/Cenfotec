package sample;
import javafx.event.ActionEvent;
public class Controller {
    public void cambiarEscena(ActionEvent event) {
        new ToScene().toScene("main.fxml",event);
    }
}
